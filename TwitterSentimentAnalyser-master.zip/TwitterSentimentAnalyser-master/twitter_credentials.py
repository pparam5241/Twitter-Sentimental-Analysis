# Variables that contains the user credentials to access Twitter API 
ACCESS_TOKEN = "1027222580996919296-bGmYagHOJbVcPG5Tfs5fnlosM6rxEW"
ACCESS_TOKEN_SECRET = "fetWjAWbUp8xZWVqIwgPzzpHKel8TrpR8x7rImy8ShLm3"
CONSUMER_KEY = "hc6kUzikRLNZKtNZhtLhIO64F"
CONSUMER_SECRET = "Z0rjeoq5so1tIcH8hWjTjdfUaOOp13KrHlLcxHXRWNiYXYudSC"